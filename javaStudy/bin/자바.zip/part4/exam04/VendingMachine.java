package part4.exam04;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeMap;

public class VendingMachine {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("�ݾ��� �Է��ϼ���. :");
		int money = scanner.nextInt();
		
		System.out.println("�޴��� ��������.");
		System.out.println("1.�ݶ�(800��) 2.����(500��) 3.��Ÿ�ο���(1500��)");
		int menu = scanner.nextInt();
		
		switch (menu) {
			case 1:
				money = money - 800;
				break;
			case 2:
				money = money - 500;
				break;
			case 3:
				money = money - 1500;
				break;
			default:
				break;
			
		}
		
		System.out.printf("�ܵ� : %d\n",money);
		int[] moneyDani = {1000,500,100,50,10,1};
		TreeMap<Integer, Integer> jandon = new TreeMap<Integer, Integer>(); // �ݾ�, ����
		
		for (int i : moneyDani) {
			if(money == 0) {
				break;
			}
			jandon.put(i, money/i);
			money = money%i;
		}


		Iterator<Integer> iterator = jandon.descendingKeySet().iterator();
		// ��� String
		String sysString = "";
		while (iterator.hasNext()) {
			int key = iterator.next();
			int value = jandon.get(key);
			
			String valueStr = null;
			
			switch (key) {
			case 1000:
				valueStr = "õ��";
				break;
			case 500:
				valueStr = "�����";
				break;
			case 100:
				valueStr = "���";
				break;
			case 50:
				valueStr = "���ʿ�";
				break;
			case 10:
				valueStr = "�ʿ�";
				break;
			case 1:
				valueStr = "�Ͽ�";
				break;
			default:
				break;
			}
			sysString += valueStr+" : "+ value+"��"+",";
		}
		sysString = sysString.substring(0,sysString.length()-1);
		System.out.println(sysString);
		
	}

}
