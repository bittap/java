package part1.exam01;

public class IfDiceExample {

	public static void main(String[] args) {
		int num = (int)(Math.random()*3)+1;
		System.out.println(num);
		switch (num) {
		case 1:
			System.out.println("����");
			break;
		case 2:
			System.out.println("����");
			break;

		default:
			System.out.println("��");
			break;
		}
	}

}
