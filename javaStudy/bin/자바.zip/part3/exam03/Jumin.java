package part3.exam03;

import java.util.Scanner;

public class Jumin {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("�ֹε�Ϲ�ȣ�� �Է��ϼ���.");
		String jumin = scanner.nextLine();
		
		String[] juminArr = jumin.split("-");
		System.out.println(juminArr[1].substring(0, 1));
		
		if(Integer.parseInt(juminArr[1].substring(0, 1)) % 2 == 1) {
			System.out.println("�����Դϴ�.");
		}else {
			System.out.println("�����Դϴ�.");
		}
		
	}

}
