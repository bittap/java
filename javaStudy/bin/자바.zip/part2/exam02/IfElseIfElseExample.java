package part2.exam02;

public class IfElseIfElseExample {

	public static void main(String[] args) {
		int score = 80;
		System.out.print("����� ");
		if(score >= 90) {
			if(score >= 97 && score <= 100) {
				System.out.println("A+");
			}else if(score >= 94 && score <= 96) {
				System.out.println("A0");
			}else {
				System.out.println("A");
			}
		}else if(score >= 80) {
			if(score >= 87 && score <= 89) {
				System.out.println("B+");
			}else if(score >= 84 && score <= 86) {
				System.out.println("B0");
			}else {
				System.out.println("B");
			}
		}else if(score >= 70) {
			if(score >= 77 && score <= 80) {
				System.out.println("C+");
			}else if(score >= 74 && score <= 76) {
				System.out.println("C0");
			}else {
				System.out.println("C");
			}
		}else {
			System.out.println("D");
		}
		System.out.print("�Դϴ�.");
	}

}
